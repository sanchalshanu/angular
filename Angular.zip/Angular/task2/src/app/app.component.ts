import { Component } from '@angular/core';
import { METHODS } from 'http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'task2';
  empData:any[]=[{id:1001,name:"Rahul",salary:9000,department:"Java"},
  {id:1002,name:"Sachin",salary:19000,department:"OraApps"},
  {id:1003,name:"Vikash",salary:29000,department:"BI"},
]
id="";name="";salary="";department="";
submit()
{
  let obj={id:this.id,name:this.name,salary:this.salary,department:this.department};
  this.empData.push(obj);
}
delete(emp)
{
  this.empData.splice(this.empData.indexOf(emp),1);
  alert("deleted");

}
id1="";name1="";salary1="";department1="";index:number;
update(emp)
{
this.id1=emp.id;
this.name1=emp.name;
this.salary1=emp.salary;
this.department1=emp.department;
this.index=this.empData.indexOf(emp);

}
updated()
{
  this.empData.splice(this.index,1,{id:this.id1,name:this.name1,salary:this.salary1,department:this.department1});
  alert("updated");
}
}

 