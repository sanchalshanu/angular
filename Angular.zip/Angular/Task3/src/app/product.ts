export class product {
        public id;
        public name: string;
        public cost;
        public online: number;
        public category: string;
        public store = [];
    
    constructor() {}
}