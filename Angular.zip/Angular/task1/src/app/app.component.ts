import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'task1';
  id="";name="";salary="";department="";

  change()
  {
    alert(this.id+" "+this.name+" "+this.salary+" "+this.department);

  }

}
