import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-book></app-book>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {

}
