import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tasktwo';
  empData:any=[
    {id:1001,name:'Rahul',salary:9000,department:'JAVA'},
                                  {id:1002,name:'Vikash',salary:11000,department:'ORAAPS'},
                                  {id:1003,name:'Uma',salary:12000,department:'JAVA'},
                                  {id:1004,name:'Sachin',salary:11500,department:'ORAAPS'},
                                  {id:1005,name:'Amol',salary:7000,department:'.NET'},
                                  {id:1006,name:'Vishal',salary:17000,department:'BI'},
                                  {id:1007,name:'Rajita',salary:21000,department:'BI'},
                                  {id:1008,name:'Neelima',salary:81000,department:'TESTING'},
                                  {id:1009,name:'Daya',salary:1000,department:'TESTING'} 
  ]

  idsort()
  {
    this.empData.sort((a,b) =>a.id < b.id ? -1 : a.id>b.id ? 1 :0);
  }
  namesort()
  {
    this.empData.sort((a,b) =>a.name < b.name ? -1 :a.name >b.name ? 1 : 0);
  }
  salarysort()
  {
    this.empData.sort((a,b) =>a.salary < b.salary ? -1 :a.salary >b.salary ? 1: 0);
  }
}
